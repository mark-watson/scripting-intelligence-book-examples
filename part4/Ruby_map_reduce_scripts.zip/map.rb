#!/usr/bin/env ruby

STDIN.each_line do |line|
  words = line.split
  doc = words.shift
  words.each do |word|
    puts "#{word}\t#{doc}"
  end
end
