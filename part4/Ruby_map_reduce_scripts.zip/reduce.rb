#!/usr/bin/env ruby

last_doc, last_word = '', ''
doc_list = []

STDIN.each_line do |line|
  word, doc = line.split("\t").collect {|w| w.strip}
  STDERR.puts("#{word} : #{doc}")
  if last_doc != '' && last_word != word
    STDERR.puts("doc_list: #{doc_list}")
    puts "#{last_word}\t#{doc_list.join(' ')}"
    doc_list = [doc]
    last_word = word
    last_doc = doc
  else
    doc_list << doc.strip
    last_word = word
    last_doc = doc
  end
end
puts "#{last_word}\t#{doc_list.join(' ')}"
