#!/usr/bin/env ruby

last_doc, last_person_name = '', ''
doc_list = []

STDIN.each_line do |line|
  person_name, doc = line.split("\t").collect {|w| w.strip}
  #STDERR.puts("#{person_name} : #{doc}")
  if last_doc != '' && last_person_name != person_name
    #STDERR.puts("doc_list: #{doc_list} #{last_person_name}")
    puts "#{last_person_name}\t#{doc_list.join(' ')}"
    doc_list = [doc]
    last_person_name = person_name
    last_doc = doc
  else
    doc_list << doc.strip
    last_person_name = person_name
    last_doc = doc
  end
end
puts "#{last_person_name}\t#{doc_list.join(' ')}"
